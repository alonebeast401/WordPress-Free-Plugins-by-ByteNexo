=== ByteNexo Reading Time ===
Contributors: bytenexo
Tags: reading time, estimated reading time, blog, posts
Requires at least: 5.8
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPL-2.0-or-later

Adds a lightweight estimated reading time badge to WordPress posts.

== Features ==

* Automatically calculates reading time from post content.
* Default reading speed: 200 words per minute.
* Clean responsive badge.
* Settings for reading speed and label.
* Optional shortcode: [bn_reading_time].
* No external libraries.

== Installation ==

1. Go to Plugins > Add New Plugin > Upload Plugin.
2. Upload the ByteNexo Reading Time ZIP.
3. Activate it.
4. Go to Settings > ByteNexo Reading Time.
5. Save your preferred reading speed.

== Notes ==

The calculation removes HTML and shortcodes before counting words. Images and other non-readable markup are not counted as words.
