<?php
/**
 * Plugin Name: ByteNexo Reading Time
 * Plugin URI: https://bytenexo.in/
 * Description: Adds a clean estimated reading time to WordPress posts based on their content.
 * Version: 1.0.0
 * Author: ByteNexo
 * Author URI: https://bytenexo.in/
 * License: GPL-2.0-or-later
 * Requires at least: 5.8
 * Requires PHP: 7.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class ByteNexo_Reading_Time {

	const OPTION_WPM   = 'bn_rt_wpm';
	const OPTION_LABEL = 'bn_rt_label';
	const OPTION_AUTO  = 'bn_rt_auto';

	public static function init() {
		add_filter( 'the_content', array( __CLASS__, 'add_reading_time' ), 8 );
		add_action( 'admin_menu', array( __CLASS__, 'admin_menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), array( __CLASS__, 'settings_link' ) );
	}

	public static function activate() {
		if ( false === get_option( self::OPTION_WPM ) ) {
			add_option( self::OPTION_WPM, 200 );
		}
		if ( false === get_option( self::OPTION_LABEL ) ) {
			add_option( self::OPTION_LABEL, 'min read' );
		}
		if ( false === get_option( self::OPTION_AUTO ) ) {
			add_option( self::OPTION_AUTO, 1 );
		}
	}

	public static function register_settings() {
		register_setting(
			'bn_rt_settings',
			self::OPTION_WPM,
			array(
				'type'              => 'integer',
				'sanitize_callback' => function( $value ) {
					$value = absint( $value );
					return min( 1000, max( 50, $value ) );
				},
				'default'           => 200,
			)
		);

		register_setting(
			'bn_rt_settings',
			self::OPTION_LABEL,
			array(
				'type'              => 'string',
				'sanitize_callback' => function( $value ) {
					$value = sanitize_text_field( $value );
					return '' === $value ? 'min read' : $value;
				},
				'default'           => 'min read',
			)
		);

		register_setting(
			'bn_rt_settings',
			self::OPTION_AUTO,
			array(
				'type'              => 'boolean',
				'sanitize_callback' => function( $value ) {
					return empty( $value ) ? 0 : 1;
				},
				'default'           => 1,
			)
		);
	}

	public static function admin_menu() {
		add_options_page(
			'ByteNexo Reading Time',
			'ByteNexo Reading Time',
			'manage_options',
			'bn-reading-time',
			array( __CLASS__, 'settings_page' )
		);
	}

	public static function settings_link( $links ) {
		$url = admin_url( 'options-general.php?page=bn-reading-time' );
		array_unshift( $links, '<a href="' . esc_url( $url ) . '">Settings</a>' );
		return $links;
	}

	public static function settings_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		?>
		<div class="wrap">
			<h1>ByteNexo Reading Time</h1>
			<p>Automatically shows an estimated reading time above published post content.</p>

			<form method="post" action="options.php">
				<?php settings_fields( 'bn_rt_settings' ); ?>

				<table class="form-table" role="presentation">
					<tr>
						<th scope="row">Automatic display</th>
						<td>
							<label>
								<input type="checkbox"
									name="<?php echo esc_attr( self::OPTION_AUTO ); ?>"
									value="1"
									<?php checked( 1, get_option( self::OPTION_AUTO, 1 ) ); ?>>
								Show reading time automatically on posts
							</label>
						</td>
					</tr>

					<tr>
						<th scope="row">Reading speed</th>
						<td>
							<input type="number"
								name="<?php echo esc_attr( self::OPTION_WPM ); ?>"
								value="<?php echo esc_attr( get_option( self::OPTION_WPM, 200 ) ); ?>"
								min="50" max="1000" step="10">
							words per minute
							<p class="description">200 WPM is a common general-purpose estimate.</p>
						</td>
					</tr>

					<tr>
						<th scope="row">Label</th>
						<td>
							<input type="text"
								name="<?php echo esc_attr( self::OPTION_LABEL ); ?>"
								value="<?php echo esc_attr( get_option( self::OPTION_LABEL, 'min read' ) ); ?>"
								class="regular-text">
							<p class="description">Example: "min read".</p>
						</td>
					</tr>
				</table>

				<?php submit_button( 'Save Settings' ); ?>
			</form>

			<hr>

			<h2>Usage</h2>
			<p>You can also place <code>[bn_reading_time]</code> inside a post if automatic display is disabled.</p>
		</div>
		<?php
	}

	public static function add_reading_time( $content ) {
		if ( ! is_singular( 'post' ) || ! in_the_loop() || ! is_main_query() ) {
			return $content;
		}

		if ( ! get_option( self::OPTION_AUTO, 1 ) ) {
			return $content;
		}

		return self::get_badge() . $content;
	}

	public static function shortcode() {
		return self::get_badge();
	}

	private static function get_badge() {
		$post_id = get_the_ID();

		if ( ! $post_id ) {
			return '';
		}

		$content = get_post_field( 'post_content', $post_id );

		// Remove shortcodes and HTML so only readable words are counted.
		$text = strip_shortcodes( $content );
		$text = wp_strip_all_tags( $text );
		$text = html_entity_decode( $text, ENT_QUOTES, get_bloginfo( 'charset' ) ?: 'UTF-8' );
		$text = preg_replace( '/\s+/u', ' ', trim( $text ) );

		if ( '' === $text ) {
			return '';
		}

		$words = preg_split( '/\s+/u', $text, -1, PREG_SPLIT_NO_EMPTY );
		$count = is_array( $words ) ? count( $words ) : 0;

		$wpm = absint( get_option( self::OPTION_WPM, 200 ) );
		$wpm = max( 50, $wpm );

		$minutes = max( 1, (int) ceil( $count / $wpm ) );
		$label   = get_option( self::OPTION_LABEL, 'min read' );

		ob_start();
		?>
		<div class="bn-reading-time" style="
			display:flex;
			align-items:center;
			gap:8px;
			width:max-content;
			max-width:100%;
			margin:0 0 18px;
			padding:8px 12px;
			border:1px solid #dbe4f0;
			border-radius:999px;
			background:#f7faff;
			color:#334155;
			font:500 14px/1.2 system-ui,-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;
			box-sizing:border-box;
		" aria-label="<?php echo esc_attr( $minutes . ' ' . $label ); ?>">
			<span aria-hidden="true" style="
				display:inline-flex;
				align-items:center;
				justify-content:center;
				width:24px;
				height:24px;
				border-radius:50%;
				background:#e7f0ff;
				color:#2563eb;
				font-size:14px;
			">◷</span>
			<span>
				<strong style="font-weight:700;color:#1e293b;">
					<?php echo esc_html( $minutes ); ?>
				</strong>
				<?php echo esc_html( ' ' . $label ); ?>
			</span>
		</div>
		<?php
		return ob_get_clean();
	}
}

ByteNexo_Reading_Time::init();

add_shortcode( 'bn_reading_time', array( 'ByteNexo_Reading_Time', 'shortcode' ) );

register_activation_hook( __FILE__, array( 'ByteNexo_Reading_Time', 'activate' ) );
