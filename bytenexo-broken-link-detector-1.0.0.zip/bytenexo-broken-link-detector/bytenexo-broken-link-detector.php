<?php
/**
 * Plugin Name: ByteNexo Broken Link Detector
 * Plugin URI: https://bytenexo.in/
 * Description: Advanced WordPress broken-link scanner. Scans published posts, detects HTTP errors and unreachable URLs, shows the source post and broken URL, and lets administrators remove selected links directly.
 * Version: 1.0.0
 * Author: ByteNexo
 * Author URI: https://bytenexo.in/
 * License: GPL-2.0-or-later
 * Requires at least: 5.8
 * Requires PHP: 7.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class ByteNexo_Broken_Link_Detector {

	const VERSION = '1.0.0';
	const NONCE   = 'bn_broken_links_nonce';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'admin_menu' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'admin_assets' ) );

		add_action( 'wp_ajax_bn_scan_posts', array( __CLASS__, 'ajax_scan_posts' ) );
		add_action( 'wp_ajax_bn_check_url', array( __CLASS__, 'ajax_check_url' ) );
		add_action( 'wp_ajax_bn_remove_links', array( __CLASS__, 'ajax_remove_links' ) );

		add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), array( __CLASS__, 'settings_link' ) );
	}

	public static function admin_menu() {
		add_management_page(
			'ByteNexo Broken Links',
			'Broken Links',
			'manage_options',
			'bn-broken-links',
			array( __CLASS__, 'page' )
		);
	}

	public static function settings_link( $links ) {
		array_unshift(
			$links,
			'<a href="' . esc_url( admin_url( 'tools.php?page=bn-broken-links' ) ) . '">Open Scanner</a>'
		);
		return $links;
	}

	public static function admin_assets( $hook ) {
		if ( 'tools_page_bn-broken-links' !== $hook ) {
			return;
		}

		wp_enqueue_style( 'dashicons' );

		wp_register_style( 'bn-broken-links', false, array(), self::VERSION );
		wp_enqueue_style( 'bn-broken-links' );

		wp_add_inline_style( 'bn-broken-links', self::css() );

		wp_register_script( 'bn-broken-links', false, array(), self::VERSION, true );
		wp_enqueue_script( 'bn-broken-links' );

		wp_add_inline_script(
			'bn-broken-links',
			'window.BNBrokenLinks=' . wp_json_encode(
				array(
					'ajax'  => admin_url( 'admin-ajax.php' ),
					'nonce' => wp_create_nonce( self::NONCE ),
				)
			) . ';' . self::js()
		);
	}

	private static function css() {
		return '
		.bn-wrap{max-width:1250px;margin:22px 20px 40px 0;font-family:system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}
		.bn-hero{background:linear-gradient(135deg,#0f172a,#1d4ed8);color:#fff;border-radius:16px;padding:24px 26px;margin-bottom:18px;box-shadow:0 8px 30px rgba(15,23,42,.12)}
		.bn-hero h1{color:#fff;margin:0 0 7px;font-size:25px}.bn-hero p{margin:0;color:#dbeafe;font-size:14px}
		.bn-toolbar{background:#fff;border:1px solid #dbe4ef;border-radius:14px;padding:15px;display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin-bottom:15px}
		.bn-btn{border:0;border-radius:9px;padding:10px 15px;font-weight:700;cursor:pointer}.bn-primary{background:#2563eb;color:#fff}.bn-danger{background:#dc2626;color:#fff}.bn-muted{background:#eef2f7;color:#334155}
		.bn-btn:disabled{opacity:.55;cursor:not-allowed}.bn-status{font-size:13px;color:#64748b;margin-left:auto}
		.bn-stats{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin-bottom:15px}
		.bn-stat{background:#fff;border:1px solid #dbe4ef;border-radius:12px;padding:15px}.bn-stat strong{display:block;font-size:25px;color:#172033}.bn-stat span{font-size:12px;color:#64748b}
		.bn-table-wrap{background:#fff;border:1px solid #dbe4ef;border-radius:14px;overflow:auto}
		.bn-table{width:100%;border-collapse:collapse;min-width:850px}.bn-table th,.bn-table td{padding:12px 13px;border-bottom:1px solid #edf1f5;text-align:left;vertical-align:top}.bn-table th{background:#f8fafc;font-size:12px;text-transform:uppercase;color:#64748b}
		.bn-table tr:last-child td{border-bottom:0}.bn-url{word-break:break-all;color:#b91c1c;font-size:13px}.bn-post a{font-weight:700;text-decoration:none}.bn-post small{display:block;color:#64748b;margin-top:3px}
		.bn-badge{display:inline-block;border-radius:999px;padding:4px 8px;font-size:11px;font-weight:700}.bn-broken{background:#fee2e2;color:#b91c1c}.bn-timeout{background:#fef3c7;color:#92400e}.bn-ok{background:#dcfce7;color:#166534}
		.bn-empty{padding:35px;text-align:center;color:#64748b}.bn-check{width:17px;height:17px}
		.bn-progress{height:6px;background:#e5e7eb;border-radius:99px;overflow:hidden;margin-top:10px;display:none}.bn-progress span{display:block;height:100%;width:0;background:#2563eb;transition:width .15s}
		.bn-help{background:#f8fafc;border:1px solid #e2e8f0;border-radius:12px;padding:14px;margin-top:15px;color:#475569;font-size:13px}
		@media(max-width:800px){.bn-stats{grid-template-columns:repeat(2,1fr)}.bn-status{width:100%;margin-left:0}}
		';
	}

	private static function js() {
		return <<<'JS'
(function(){
	'use strict';

	const cfg = window.BNBrokenLinks || {};
	const $ = (s) => document.querySelector(s);
	const results = $('#bn-results');
	const scanBtn = $('#bn-scan');
	const removeBtn = $('#bn-remove');
	const progress = $('#bn-progress');
	const progressBar = $('#bn-progress-bar');
	const status = $('#bn-status');

	function post(data){
		data.action = data.action || '';
		data.nonce = cfg.nonce;
		return fetch(cfg.ajax,{
			method:'POST',
			headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'},
			body:new URLSearchParams(data)
		}).then(r=>r.json());
	}

	function escapeHtml(v){
		const d=document.createElement('div'); d.textContent=v || ''; return d.innerHTML;
	}

	function render(rows){
		if(!rows.length){
			results.innerHTML='<div class="bn-empty">No broken links were found in the scanned posts.</div>';
			return;
		}

		let html='<table class="bn-table"><thead><tr>'+
			'<th><input type="checkbox" id="bn-select-all"></th>'+
			'<th>Broken URL</th><th>Source Post</th><th>Status</th><th>Action</th>'+
			'</tr></thead><tbody>';

		rows.forEach((r,i)=>{
			html+='<tr data-index="'+i+'">'+
				'<td><input class="bn-check" type="checkbox" value="'+i+'"></td>'+
				'<td><div class="bn-url">'+escapeHtml(r.url)+'</div><small>'+escapeHtml(r.type || '')+'</small></td>'+
				'<td class="bn-post"><a target="_blank" rel="noopener" href="'+escapeHtml(r.post_edit)+'">'+escapeHtml(r.post_title)+'</a><small>'+escapeHtml(r.post_type_label)+'</small></td>'+
				'<td><span class="bn-badge '+(r.kind==='timeout'?'bn-timeout':'bn-broken')+'">'+escapeHtml(r.status_label)+'</span></td>'+
				'<td><button class="bn-btn bn-danger bn-remove-one" data-index="'+i+'">Remove Link</button></td>'+
				'</tr>';
		});
		html+='</tbody></table>';
		results.innerHTML=html;

		$('#bn-select-all').addEventListener('change',e=>{
			document.querySelectorAll('.bn-check').forEach(c=>c.checked=e.target.checked);
			updateRemoveButton();
		});
		document.querySelectorAll('.bn-check').forEach(c=>c.addEventListener('change',updateRemoveButton));
		document.querySelectorAll('.bn-remove-one').forEach(b=>b.addEventListener('click',()=>{
			removeIndexes([parseInt(b.dataset.index,10)]);
		}));
		updateRemoveButton();
	}

	function updateRemoveButton(){
		const count=document.querySelectorAll('.bn-check:checked').length;
		removeBtn.disabled=count===0;
		removeBtn.textContent=count ? 'Remove Selected ('+count+')' : 'Remove Selected';
	}

	function setStats(scanned, broken){
		$('#bn-scanned').textContent=scanned;
		$('#bn-broken').textContent=broken;
		$('#bn-last').textContent=new Date().toLocaleTimeString();
		$('#bn-selected').textContent='0';
	}

	function removeIndexes(indexes){
		if(!window.BNBrokenRows || !indexes.length)return;
		if(!confirm('Remove the selected broken link(s) from the post content? The link text will be kept.'))return;

		removeBtn.disabled=true;
		status.textContent='Removing links...';

		const items=indexes.map(i=>BNBrokenRows[i]).filter(Boolean);

		post({
			action:'bn_remove_links',
			items:JSON.stringify(items)
		}).then(res=>{
			if(!res.success){throw new Error(res.data && res.data.message ? res.data.message : 'Could not remove links.');}
			const removed=res.data.removed || [];
			const failed=res.data.failed || [];

			BNBrokenRows=BNBrokenRows.filter((r,i)=>!indexes.includes(i));
			render(BNBrokenRows);
			$('#bn-broken').textContent=BNBrokenRows.length;
			status.textContent=removed.length+' link(s) removed.'+(failed.length?' '+failed.length+' could not be removed.':'');
		}).catch(err=>{
			alert(err.message);
			status.textContent='Action failed.';
			updateRemoveButton();
		});
	}

	scanBtn.addEventListener('click',()=>{
		scanBtn.disabled=true;
		removeBtn.disabled=true;
		status.textContent='Scanning posts and checking URLs...';
		progress.style.display='block';
		progressBar.style.width='5%';
		results.innerHTML='<div class="bn-empty">Scanning published posts. Please wait...</div>';

		post({action:'bn_scan_posts'}).then(res=>{
			if(!res.success){throw new Error(res.data && res.data.message ? res.data.message : 'Scan failed.');}
			BNBrokenRows=res.data.rows || [];
			render(BNBrokenRows);
			setStats(res.data.scanned_posts || 0, BNBrokenRows.length);
			progressBar.style.width='100%';
			status.textContent='Scan complete.';
		}).catch(err=>{
			results.innerHTML='<div class="bn-empty">Error: '+escapeHtml(err.message)+'</div>';
			status.textContent='Scan failed.';
		}).finally(()=>{
			scanBtn.disabled=false;
			setTimeout(()=>{progress.style.display='none';progressBar.style.width='0'},700);
		});
	});

	removeBtn.addEventListener('click',()=>{
		const indexes=[...document.querySelectorAll('.bn-check:checked')].map(c=>parseInt(c.value,10));
		removeIndexes(indexes);
	});

	window.BNBrokenRows=[];
})();
JS;
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'bn-broken-links' ) );
		}
		?>
		<div class="bn-wrap">
			<div class="bn-hero">
				<h1>ByteNexo Broken Link Detector</h1>
				<p>Scan your published posts, find broken URLs, open the source post, and remove selected broken links directly from WordPress.</p>
			</div>

			<div class="bn-toolbar">
				<button id="bn-scan" class="bn-btn bn-primary">Scan All Published Posts</button>
				<button id="bn-remove" class="bn-btn bn-danger" disabled>Remove Selected</button>
				<span id="bn-status" class="bn-status">Ready to scan.</span>
			</div>

			<div id="bn-progress" class="bn-progress"><span id="bn-progress-bar"></span></div>

			<div class="bn-stats">
				<div class="bn-stat"><strong id="bn-scanned">0</strong><span>Posts scanned</span></div>
				<div class="bn-stat"><strong id="bn-broken">0</strong><span>Broken links found</span></div>
				<div class="bn-stat"><strong id="bn-selected">0</strong><span>Selected for removal</span></div>
				<div class="bn-stat"><strong id="bn-last">—</strong><span>Last scan time</span></div>
			</div>

			<div id="bn-results" class="bn-table-wrap">
				<div class="bn-empty">
					<strong>No scan performed yet.</strong><br>
					Click “Scan All Published Posts” to check your post links.
				</div>
			</div>

			<div class="bn-help">
				<strong>How removal works:</strong> ByteNexo removes only the broken <code>&lt;a&gt;</code> link wrapper and keeps the visible anchor text. It updates the affected post only after you explicitly choose the removal action.
				<br><br>
				<strong>Detected:</strong> 4xx/5xx HTTP responses, connection failures and timeouts. Redirects with a successful final response are treated as working links.
			</div>
		</div>
		<?php
	}

	public static function verify_request() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Permission denied.' ), 403 );
		}
		check_ajax_referer( self::NONCE, 'nonce' );
	}

	public static function ajax_scan_posts() {
		self::verify_request();

		$post_ids = get_posts(
			array(
				'post_type'              => 'post',
				'post_status'            => 'publish',
				'posts_per_page'         => -1,
				'fields'                 => 'ids',
				'orderby'                => 'date',
				'order'                  => 'DESC',
				'no_found_rows'          => true,
				'update_post_meta_cache' => false,
				'update_post_term_cache' => false,
			)
		);

		$rows = array();

		foreach ( $post_ids as $post_id ) {
			$content = get_post_field( 'post_content', $post_id );
			if ( ! $content || false === stripos( $content, '<a' ) ) {
				continue;
			}

			$links = self::extract_links( $content );

			foreach ( $links as $link ) {
				$url = $link['url'];

				// Skip non-web links.
				if ( ! preg_match( '#^https?://#i', $url ) ) {
					continue;
				}

				$result = self::check_url( $url );

				if ( ! $result['broken'] ) {
					continue;
				}

				$rows[] = array(
					'key'            => md5( $post_id . '|' . $url . '|' . $link['start'] ),
					'post_id'        => (int) $post_id,
					'post_title'     => get_the_title( $post_id ),
					'post_edit'      => get_edit_post_link( $post_id, '' ),
					'post_type_label'=> 'Published Post',
					'url'            => $url,
					'status'         => $result['status'],
					'status_label'   => $result['label'],
					'kind'           => $result['kind'],
					'anchor'         => $link['text'],
					'start'          => $link['start'],
					'end'            => $link['end'],
				);
			}
		}

		wp_send_json_success(
			array(
				'scanned_posts' => count( $post_ids ),
				'rows'          => $rows,
			)
		);
	}

	public static function ajax_check_url() {
		self::verify_request();

		$url = isset( $_POST['url'] ) ? esc_url_raw( wp_unslash( $_POST['url'] ) ) : '';

		if ( ! $url || ! preg_match( '#^https?://#i', $url ) ) {
			wp_send_json_error( array( 'message' => 'Invalid URL.' ), 400 );
		}

		wp_send_json_success( self::check_url( $url ) );
	}

	private static function check_url( $url ) {
		$args = array(
			'timeout'     => 8,
			'redirection' => 5,
			'user-agent'  => 'ByteNexo Broken Link Detector/' . self::VERSION . '; ' . home_url( '/' ),
			'sslverify'   => true,
			'headers'     => array(
				'Accept' => 'text/html,application/xhtml+xml,*/*;q=0.8',
			),
		);

		$response = wp_remote_head( $url, $args );

		// Some servers reject HEAD. Fall back to GET with a small body limit.
		if ( is_wp_error( $response ) || (int) wp_remote_retrieve_response_code( $response ) === 405 ) {
			$response = wp_remote_get(
				$url,
				array_merge(
					$args,
					array(
						'limit_response_size' => 1024,
					)
				)
			);
		}

		if ( is_wp_error( $response ) ) {
			return array(
				'broken' => true,
				'status' => 0,
				'label'  => 'Unreachable / Timeout',
				'kind'   => 'timeout',
			);
		}

		$code = (int) wp_remote_retrieve_response_code( $response );

		if ( $code >= 400 || 0 === $code ) {
			return array(
				'broken' => true,
				'status' => $code,
				'label'  => $code ? 'HTTP ' . $code : 'No Response',
				'kind'   => 'broken',
			);
		}

		return array(
			'broken' => false,
			'status' => $code,
			'label'  => 'Working',
			'kind'   => 'ok',
		);
	}

	private static function extract_links( $content ) {
		$links = array();

		if ( ! preg_match_all( '/<a\b[^>]*href\s*=\s*(["\'])(.*?)\1[^>]*>(.*?)<\/a>/is', $content, $matches, PREG_OFFSET_CAPTURE ) ) {
			return $links;
		}

		foreach ( $matches[0] as $i => $full_match ) {
			$full  = $full_match[0];
			$start = $full_match[1];

			$href = html_entity_decode( $matches[2][ $i ][0], ENT_QUOTES, 'UTF-8' );
			$text = trim( wp_strip_all_tags( $matches[3][ $i ][0] ) );

			$links[] = array(
				'url'   => $href,
				'text'  => $text,
				'start' => $start,
				'end'   => $start + strlen( $full ),
				'html'  => $full,
			);
		}

		return $links;
	}

	public static function ajax_remove_links() {
		self::verify_request();

		$json = isset( $_POST['items'] ) ? wp_unslash( $_POST['items'] ) : '';
		$items = json_decode( $json, true );

		if ( ! is_array( $items ) ) {
			wp_send_json_error( array( 'message' => 'Invalid selection.' ), 400 );
		}

		$grouped = array();

		foreach ( $items as $item ) {
			$post_id = isset( $item['post_id'] ) ? absint( $item['post_id'] ) : 0;
			$url     = isset( $item['url'] ) ? esc_url_raw( $item['url'] ) : '';

			if ( ! $post_id || ! $url ) {
				continue;
			}

			$grouped[ $post_id ][] = array(
				'url' => $url,
			);
		}

		$removed = array();
		$failed  = array();

		foreach ( $grouped as $post_id => $selected ) {
			$post = get_post( $post_id );

			if ( ! $post || 'post' !== $post->post_type || 'publish' !== $post->post_status ) {
				continue;
			}

			$content = $post->post_content;

			foreach ( $selected as $target ) {
				$result = self::remove_url_from_content( $content, $target['url'] );

				if ( $result['changed'] ) {
					$content = $result['content'];
					$removed[] = array(
						'post_id' => $post_id,
						'url'     => $target['url'],
					);
				} else {
					$failed[] = array(
						'post_id' => $post_id,
						'url'     => $target['url'],
					);
				}
			}

			if ( $content !== $post->post_content ) {
				wp_update_post(
					array(
						'ID'           => $post_id,
						'post_content' => $content,
					)
				);
			}
		}

		wp_send_json_success(
			array(
				'removed' => $removed,
				'failed'  => $failed,
			)
		);
	}

	private static function remove_url_from_content( $content, $target_url ) {
		$changed = false;

		$pattern = '/<a\b([^>]*\bhref\s*=\s*)(["\'])(.*?)\2([^>]*)>(.*?)<\/a>/is';

		$new = preg_replace_callback(
			$pattern,
			function( $m ) use ( $target_url, &$changed ) {
				$href = html_entity_decode( $m[3], ENT_QUOTES, 'UTF-8' );

				if ( self::urls_equal( $href, $target_url ) ) {
					$changed = true;
					return $m[5]; // Keep visible text/content, remove only the anchor.
				}

				return $m[0];
			},
			$content
		);

		return array(
			'changed' => $changed,
			'content' => $new,
		);
	}

	private static function urls_equal( $a, $b ) {
		$a = trim( html_entity_decode( $a, ENT_QUOTES, 'UTF-8' ) );
		$b = trim( html_entity_decode( $b, ENT_QUOTES, 'UTF-8' ) );

		$pa = wp_parse_url( $a );
		$pb = wp_parse_url( $b );

		if ( ! is_array( $pa ) || ! is_array( $pb ) ) {
			return $a === $b;
		}

		$normalize = function( $p ) {
			$scheme = isset( $p['scheme'] ) ? strtolower( $p['scheme'] ) : '';
			$host   = isset( $p['host'] ) ? strtolower( $p['host'] ) : '';
			$port   = isset( $p['port'] ) ? ':' . $p['port'] : '';
			$path   = isset( $p['path'] ) ? rtrim( $p['path'], '/' ) : '';
			$query  = isset( $p['query'] ) ? '?' . $p['query'] : '';
			return $scheme . '://' . $host . $port . $path . $query;
		};

		return $normalize( $pa ) === $normalize( $pb );
	}
}

ByteNexo_Broken_Link_Detector::init();
