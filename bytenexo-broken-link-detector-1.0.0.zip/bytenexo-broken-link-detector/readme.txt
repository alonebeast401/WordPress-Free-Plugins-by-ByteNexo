=== ByteNexo Broken Link Detector ===
Contributors: bytenexo
Tags: broken links, link checker, seo, links, wordpress
Requires at least: 5.8
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPL-2.0-or-later

Advanced broken-link scanner for WordPress posts with direct removal controls.

== Features ==

* Scans all published normal posts.
* Extracts HTTP and HTTPS links from post content.
* Checks links using WordPress HTTP API.
* Follows redirects.
* Falls back from HEAD to GET when a server rejects HEAD.
* Detects HTTP 4xx and 5xx responses.
* Detects unreachable URLs and request failures.
* Shows broken URL, source post, status, and direct edit link.
* Select individual broken links.
* Select all broken links.
* Remove selected links directly from the scanner.
* Removing a link keeps its visible anchor text.
* Does not remove the entire sentence or paragraph.
* Updates only the affected posts.
* Admin-only access.
* Nonce and capability checks on AJAX actions.
* No external libraries.

== Installation ==

1. Go to WordPress > Plugins > Add New Plugin > Upload Plugin.
2. Upload the ZIP file.
3. Activate the plugin.
4. Go to Tools > Broken Links.
5. Click Scan All Published Posts.

== Removing links ==

Select one or more broken links and click Remove Selected. The plugin removes the <a> wrapper while keeping the visible link text.

Example:

<a href="https://example.com">Download tool</a>

becomes:

Download tool

The post content is changed only when you explicitly choose a removal action.

== Important ==

Some websites block automated requests, bots, HEAD requests, or security scanners. Such a URL may appear unreachable even though it works in a normal browser. Review the result before removing a link.

The plugin currently scans normal published WordPress posts. It does not automatically alter links without administrator confirmation.
