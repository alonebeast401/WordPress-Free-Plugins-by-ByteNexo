<?php
/**
 * Plugin Name: ByteNexo Image SEO Sync
 * Plugin URI: https://bytenexo.in/
 * Description: Automatically syncs a post title to image ALT text and the post SEO meta description to the image attachment description.
 * Version: 1.0.0
 * Author: ByteNexo
 * Author URI: https://bytenexo.in/
 * License: GPL-2.0-or-later
 * Requires at least: 5.8
 * Requires PHP: 7.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class ByteNexo_Image_SEO_Sync {

	const OPTION_OVERWRITE_ALT  = 'bn_ises_overwrite_alt';
	const OPTION_OVERWRITE_DESC = 'bn_ises_overwrite_desc';

	public static function init() {
		add_action( 'save_post', array( __CLASS__, 'sync_post_images' ), 20, 3 );
		add_action( 'add_attachment', array( __CLASS__, 'sync_attachment_on_upload' ) );
		add_action( 'admin_menu', array( __CLASS__, 'admin_menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
	}

	public static function activate() {
		if ( false === get_option( self::OPTION_OVERWRITE_ALT ) ) {
			add_option( self::OPTION_OVERWRITE_ALT, 0 );
		}
		if ( false === get_option( self::OPTION_OVERWRITE_DESC ) ) {
			add_option( self::OPTION_OVERWRITE_DESC, 0 );
		}
	}

	public static function register_settings() {
		register_setting(
			'bn_ises_settings',
			self::OPTION_OVERWRITE_ALT,
			array(
				'type'              => 'boolean',
				'sanitize_callback' => function( $value ) { return ! empty( $value ) ? 1 : 0; },
				'default'           => 0,
			)
		);

		register_setting(
			'bn_ises_settings',
			self::OPTION_OVERWRITE_DESC,
			array(
				'type'              => 'boolean',
				'sanitize_callback' => function( $value ) { return ! empty( $value ) ? 1 : 0; },
				'default'           => 0,
			)
		);
	}

	public static function admin_menu() {
		add_options_page(
			'ByteNexo Image SEO Sync',
			'ByteNexo Image SEO',
			'manage_options',
			'bn-image-seo-sync',
			array( __CLASS__, 'settings_page' )
		);
	}

	public static function settings_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		?>
		<div class="wrap">
			<h1>ByteNexo Image SEO Sync</h1>
			<p>
				When a post is saved, this plugin finds images used in that post and
				syncs their ALT text and attachment description.
			</p>

			<form method="post" action="options.php">
				<?php settings_fields( 'bn_ises_settings' ); ?>

				<table class="form-table" role="presentation">
					<tr>
						<th scope="row">Overwrite existing ALT text</th>
						<td>
							<label>
								<input type="checkbox"
									name="<?php echo esc_attr( self::OPTION_OVERWRITE_ALT ); ?>"
									value="1"
									<?php checked( 1, get_option( self::OPTION_OVERWRITE_ALT, 0 ) ); ?>>
								Replace existing ALT text with the post title.
							</label>
							<p class="description">
								Leave disabled to update only images that have an empty ALT text.
							</p>
						</td>
					</tr>

					<tr>
						<th scope="row">Overwrite existing image descriptions</th>
						<td>
							<label>
								<input type="checkbox"
									name="<?php echo esc_attr( self::OPTION_OVERWRITE_DESC ); ?>"
									value="1"
									<?php checked( 1, get_option( self::OPTION_OVERWRITE_DESC, 0 ) ); ?>>
								Replace existing attachment descriptions with the post meta description.
							</label>
							<p class="description">
								Leave disabled to update only images that have an empty description.
							</p>
						</td>
					</tr>
				</table>

				<?php submit_button( 'Save Settings' ); ?>
			</form>

			<hr>

			<h2>How it works</h2>
			<ul>
				<li><strong>ALT:</strong> uses the post title, cleaned and normalized.</li>
				<li><strong>Description:</strong> checks Rank Math, Yoast SEO and AIOSEO meta description fields, then falls back to the post excerpt.</li>
				<li>It processes images attached to the post and images whose attachment IDs are present in the post content.</li>
				<li>Existing values are preserved by default.</li>
			</ul>
		</div>
		<?php
	}

	public static function sync_post_images( $post_id, $post, $update ) {
		if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) {
			return;
		}

		if ( ! $post || 'publish' !== $post->post_status && 'future' !== $post->post_status ) {
			return;
		}

		if ( 'post' !== $post->post_type && 'page' !== $post->post_type ) {
			return;
		}

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		self::sync_images_for_post( $post_id );
	}

	public static function sync_attachment_on_upload( $attachment_id ) {
		$parent_id = (int) wp_get_post_parent_id( $attachment_id );

		if ( $parent_id > 0 ) {
			self::sync_images_for_post( $parent_id );
		}
	}

	private static function sync_images_for_post( $post_id ) {
		$post = get_post( $post_id );

		if ( ! $post ) {
			return;
		}

		$attachment_ids = self::get_image_attachment_ids( $post_id );

		if ( empty( $attachment_ids ) ) {
			return;
		}

		$alt_text    = self::professional_title( get_the_title( $post_id ) );
		$description = self::get_meta_description( $post_id );

		foreach ( $attachment_ids as $attachment_id ) {
			if ( $alt_text ) {
				self::sync_alt( $attachment_id, $alt_text );
			}

			if ( $description ) {
				self::sync_description( $attachment_id, $description );
			}
		}
	}

	private static function get_image_attachment_ids( $post_id ) {
		$ids = array();

		// Featured image.
		$featured_id = get_post_thumbnail_id( $post_id );
		if ( $featured_id && wp_attachment_is_image( $featured_id ) ) {
			$ids[] = (int) $featured_id;
		}

		$post = get_post( $post_id );
		if ( ! $post ) {
			return array_values( array_unique( $ids ) );
		}

		// Images in classic-editor content / blocks containing attachment IDs.
		$content = (string) $post->post_content;

		if ( preg_match_all( '/wp-image-([0-9]+)/i', $content, $matches ) ) {
			foreach ( $matches[1] as $id ) {
				$id = (int) $id;
				if ( $id && wp_attachment_is_image( $id ) ) {
					$ids[] = $id;
				}
			}
		}

		// Catch image URLs that may not contain a wp-image class.
		if ( preg_match_all( '/<img[^>]+src=["\']([^"\']+)["\']/i', $content, $matches ) ) {
			foreach ( $matches[1] as $url ) {
				$attachment_id = attachment_url_to_postid( $url );
				if ( $attachment_id && wp_attachment_is_image( $attachment_id ) ) {
					$ids[] = (int) $attachment_id;
				}
			}
		}

		// Gallery / image blocks can store IDs in block markup.
		if ( function_exists( 'parse_blocks' ) ) {
			$blocks = parse_blocks( $content );
			$ids    = array_merge( $ids, self::find_image_ids_in_blocks( $blocks ) );
		}

		return array_values( array_unique( array_filter( array_map( 'intval', $ids ) ) ) );
	}

	private static function find_image_ids_in_blocks( $blocks ) {
		$ids = array();

		foreach ( (array) $blocks as $block ) {
			if ( ! empty( $block['attrs'] ) && is_array( $block['attrs'] ) ) {
				foreach ( array( 'id', 'mediaId', 'imageId' ) as $key ) {
					if ( ! empty( $block['attrs'][ $key ] ) ) {
						$id = (int) $block['attrs'][ $key ];
						if ( $id && wp_attachment_is_image( $id ) ) {
							$ids[] = $id;
						}
					}
				}

				if ( ! empty( $block['attrs']['ids'] ) && is_array( $block['attrs']['ids'] ) ) {
					foreach ( $block['attrs']['ids'] as $id ) {
						$id = (int) $id;
						if ( $id && wp_attachment_is_image( $id ) ) {
							$ids[] = $id;
						}
					}
				}
			}

			if ( ! empty( $block['innerBlocks'] ) ) {
				$ids = array_merge( $ids, self::find_image_ids_in_blocks( $block['innerBlocks'] ) );
			}
		}

		return $ids;
	}

	private static function sync_alt( $attachment_id, $alt_text ) {
		$current = (string) get_post_meta( $attachment_id, '_wp_attachment_image_alt', true );
		$overwrite = (int) get_option( self::OPTION_OVERWRITE_ALT, 0 );

		if ( $overwrite || '' === trim( $current ) ) {
			update_post_meta( $attachment_id, '_wp_attachment_image_alt', $alt_text );
		}
	}

	private static function sync_description( $attachment_id, $description ) {
		$attachment = get_post( $attachment_id );

		if ( ! $attachment || 'attachment' !== $attachment->post_type ) {
			return;
		}

		$current   = trim( wp_strip_all_tags( (string) $attachment->post_content ) );
		$overwrite = (int) get_option( self::OPTION_OVERWRITE_DESC, 0 );

		if ( $overwrite || '' === $current ) {
			wp_update_post(
				array(
					'ID'           => $attachment_id,
					'post_content' => $description,
				)
			);
		}
	}

	private static function professional_title( $title ) {
		$title = wp_strip_all_tags( (string) $title );
		$title = html_entity_decode( $title, ENT_QUOTES, get_bloginfo( 'charset' ) ?: 'UTF-8' );
		$title = preg_replace( '/\s+/u', ' ', $title );
		$title = trim( $title );

		if ( '' === $title ) {
			return '';
		}

		// Keep ALT descriptive without adding artificial keyword stuffing.
		return sanitize_text_field( $title );
	}

	private static function get_meta_description( $post_id ) {
		$keys = array(
			'_rank_math_description',
			'_yoast_wpseo_metadesc',
			'_aioseo_description',
		);

		foreach ( $keys as $key ) {
			$value = get_post_meta( $post_id, $key, true );
			$value = self::clean_description( $value );

			if ( $value ) {
				return $value;
			}
		}

		// Fallback to the manually entered excerpt.
		$excerpt = get_post_field( 'post_excerpt', $post_id );
		$excerpt = self::clean_description( $excerpt );

		if ( $excerpt ) {
			return $excerpt;
		}

		return '';
	}

	private static function clean_description( $value ) {
		$value = wp_strip_all_tags( (string) $value );
		$value = html_entity_decode( $value, ENT_QUOTES, get_bloginfo( 'charset' ) ?: 'UTF-8' );
		$value = preg_replace( '/\s+/u', ' ', $value );
		$value = trim( $value );

		if ( '' === $value ) {
			return '';
		}

		// Keep attachment descriptions concise and natural.
		if ( function_exists( 'mb_substr' ) ) {
			$value = mb_substr( $value, 0, 300 );
		} else {
			$value = substr( $value, 0, 300 );
		}

		return sanitize_text_field( $value );
	}
}

ByteNexo_Image_SEO_Sync::init();
register_activation_hook( __FILE__, array( 'ByteNexo_Image_SEO_Sync', 'activate' ) );
