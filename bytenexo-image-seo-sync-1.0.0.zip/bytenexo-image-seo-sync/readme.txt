=== ByteNexo Image SEO Sync ===
Contributors: bytenexo
Tags: image seo, alt text, image description, seo, accessibility
Requires at least: 5.8
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPL-2.0-or-later

Automatically sync post titles to image ALT text and SEO meta descriptions to image attachment descriptions.

== Description ==

When a post is saved, the plugin finds its featured image and images used in the post content.

By default:
* Empty image ALT text is filled with the post title.
* Empty image attachment descriptions are filled with the post SEO meta description.
* Existing values are preserved.

Supported SEO description fields:
* Rank Math
* Yoast SEO
* AIOSEO
* Post excerpt as fallback

Settings are available under Settings > ByteNexo Image SEO.

== Installation ==

1. Upload the ZIP in WordPress under Plugins > Add New > Upload Plugin.
2. Activate the plugin.
3. Open Settings > ByteNexo Image SEO.
4. Keep overwrite options disabled unless you specifically want existing values replaced.
5. Save a post to run the synchronization.

== Notes ==

The plugin does not generate keyword-stuffed ALT text. It uses the post title as a concise descriptive ALT value.
