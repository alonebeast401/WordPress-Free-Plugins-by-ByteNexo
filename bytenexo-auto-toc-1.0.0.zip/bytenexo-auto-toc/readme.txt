=== ByteNexo Auto TOC ===
Contributors: bytenexo
Tags: table of contents, toc, seo, headings, internal links, blog
Requires at least: 5.8
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPL-2.0-or-later

Advanced automatic Table of Contents for WordPress posts.

== Features ==

* Automatically detects H2-H6 headings.
* Select which heading levels to include.
* Creates clean unique anchor IDs.
* Preserves an existing heading ID when possible.
* Handles duplicate heading names safely.
* Smooth scrolling.
* Current section highlighting with IntersectionObserver.
* Optional sticky desktop TOC.
* Optional reading progress bar.
* Optional collapsed state.
* Clean responsive design.
* Automatic top or bottom placement.
* Shortcode support: [bn_toc]
* Heading exclusion using data-bn-toc-ignore="1".
* No external CSS or JavaScript libraries.
* Does not permanently rewrite post_content in the database.

== Installation ==

1. Go to WordPress > Plugins > Add New Plugin > Upload Plugin.
2. Upload the ByteNexo Auto TOC ZIP.
3. Activate the plugin.
4. Go to Settings > ByteNexo Auto TOC.
5. Configure the heading levels and advanced options.

== Shortcode ==

Use [bn_toc] when automatic placement is set to Shortcode only.

== Excluding a heading ==

Use:
<h2 data-bn-toc-ignore="1">This heading will not appear in the TOC</h2>

== Notes ==

The plugin works on normal WordPress posts and is designed to be lightweight and theme-friendly. It only modifies the rendered content through WordPress filters, so the original post content remains unchanged.
