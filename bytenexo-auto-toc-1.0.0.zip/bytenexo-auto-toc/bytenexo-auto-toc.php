<?php
/**
 * Plugin Name: ByteNexo Auto TOC
 * Plugin URI: https://bytenexo.in/
 * Description: Advanced automatic Table of Contents for WordPress posts with heading detection, unique anchors, smooth scrolling, active-section highlighting, collapse controls, progress bar, shortcode support and customization settings.
 * Version: 1.0.0
 * Author: ByteNexo
 * Author URI: https://bytenexo.in/
 * License: GPL-2.0-or-later
 * Requires at least: 5.8
 * Requires PHP: 7.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class ByteNexo_Auto_TOC {

	const VERSION       = '1.0.0';
	const OPTION_AUTO   = 'bn_toc_auto';
	const OPTION_LEVELS = 'bn_toc_levels';
	const OPTION_TITLE  = 'bn_toc_title';
	const OPTION_POS    = 'bn_toc_position';
	const OPTION_STICKY = 'bn_toc_sticky';
	const OPTION_ACTIVE = 'bn_toc_active';
	const OPTION_BAR    = 'bn_toc_progress';
	const OPTION_COLLAPSE = 'bn_toc_collapse';

	public static function init() {
		add_filter( 'the_content', array( __CLASS__, 'filter_content' ), 12 );
		add_shortcode( 'bn_toc', array( __CLASS__, 'shortcode' ) );

		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
		add_action( 'admin_menu', array( __CLASS__, 'admin_menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), array( __CLASS__, 'settings_link' ) );
	}

	public static function activate() {
		$defaults = array(
			self::OPTION_AUTO     => 1,
			self::OPTION_LEVELS   => 'h2,h3',
			self::OPTION_TITLE    => 'Table of Contents',
			self::OPTION_POS      => 'top',
			self::OPTION_STICKY   => 0,
			self::OPTION_ACTIVE   => 1,
			self::OPTION_BAR      => 0,
			self::OPTION_COLLAPSE => 0,
		);

		foreach ( $defaults as $key => $value ) {
			if ( false === get_option( $key ) ) {
				add_option( $key, $value );
			}
		}
	}

	public static function register_settings() {
		register_setting( 'bn_toc_settings', self::OPTION_AUTO, array(
			'type' => 'boolean',
			'sanitize_callback' => function( $v ) { return empty( $v ) ? 0 : 1; },
			'default' => 1,
		) );

		register_setting( 'bn_toc_settings', self::OPTION_LEVELS, array(
			'type' => 'string',
			'sanitize_callback' => function( $v ) {
				$allowed = array( 'h2', 'h3', 'h4', 'h5', 'h6' );
				$items = array_map( 'trim', explode( ',', strtolower( (string) $v ) ) );
				$items = array_values( array_unique( array_intersect( $items, $allowed ) ) );
				return empty( $items ) ? 'h2,h3' : implode( ',', $items );
			},
			'default' => 'h2,h3',
		) );

		register_setting( 'bn_toc_settings', self::OPTION_TITLE, array(
			'type' => 'string',
			'sanitize_callback' => 'sanitize_text_field',
			'default' => 'Table of Contents',
		) );

		register_setting( 'bn_toc_settings', self::OPTION_POS, array(
			'type' => 'string',
			'sanitize_callback' => function( $v ) {
				return in_array( $v, array( 'top', 'bottom', 'shortcode' ), true ) ? $v : 'top';
			},
			'default' => 'top',
		) );

		foreach ( array( self::OPTION_STICKY, self::OPTION_ACTIVE, self::OPTION_BAR, self::OPTION_COLLAPSE ) as $option ) {
			register_setting( 'bn_toc_settings', $option, array(
				'type' => 'boolean',
				'sanitize_callback' => function( $v ) { return empty( $v ) ? 0 : 1; },
				'default' => 0,
			) );
		}
	}

	public static function admin_menu() {
		add_options_page(
			'ByteNexo Auto TOC',
			'ByteNexo Auto TOC',
			'manage_options',
			'bn-auto-toc',
			array( __CLASS__, 'settings_page' )
		);
	}

	public static function settings_link( $links ) {
		array_unshift(
			$links,
			'<a href="' . esc_url( admin_url( 'options-general.php?page=bn-auto-toc' ) ) . '">Settings</a>'
		);
		return $links;
	}

	public static function settings_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		?>
		<div class="wrap">
			<h1>ByteNexo Auto TOC</h1>
			<p>Advanced automatic Table of Contents for your WordPress articles.</p>

			<form method="post" action="options.php">
				<?php settings_fields( 'bn_toc_settings' ); ?>

				<table class="form-table" role="presentation">
					<tr>
						<th scope="row">Automatic TOC</th>
						<td>
							<label><input type="checkbox" name="<?php echo esc_attr( self::OPTION_AUTO ); ?>" value="1" <?php checked( 1, get_option( self::OPTION_AUTO, 1 ) ); ?>> Automatically add TOC to normal posts</label>
						</td>
					</tr>

					<tr>
						<th scope="row">Heading levels</th>
						<td>
							<input type="text" class="regular-text" name="<?php echo esc_attr( self::OPTION_LEVELS ); ?>" value="<?php echo esc_attr( get_option( self::OPTION_LEVELS, 'h2,h3' ) ); ?>">
							<p class="description">Example: <code>h2,h3</code> or <code>h2,h3,h4</code>.</p>
						</td>
					</tr>

					<tr>
						<th scope="row">TOC title</th>
						<td>
							<input type="text" class="regular-text" name="<?php echo esc_attr( self::OPTION_TITLE ); ?>" value="<?php echo esc_attr( get_option( self::OPTION_TITLE, 'Table of Contents' ) ); ?>">
						</td>
					</tr>

					<tr>
						<th scope="row">Automatic position</th>
						<td>
							<select name="<?php echo esc_attr( self::OPTION_POS ); ?>">
								<option value="top" <?php selected( 'top', get_option( self::OPTION_POS, 'top' ) ); ?>>Before article content</option>
								<option value="bottom" <?php selected( 'bottom', get_option( self::OPTION_POS, 'top' ) ); ?>>After article content</option>
								<option value="shortcode" <?php selected( 'shortcode', get_option( self::OPTION_POS, 'top' ) ); ?>>Shortcode only</option>
							</select>
						</td>
					</tr>

					<tr>
						<th scope="row">Advanced UI</th>
						<td>
							<label><input type="checkbox" name="<?php echo esc_attr( self::OPTION_STICKY ); ?>" value="1" <?php checked( 1, get_option( self::OPTION_STICKY, 0 ) ); ?>> Sticky TOC on desktop</label><br>
							<label><input type="checkbox" name="<?php echo esc_attr( self::OPTION_ACTIVE ); ?>" value="1" <?php checked( 1, get_option( self::OPTION_ACTIVE, 1 ) ); ?>> Highlight the current section</label><br>
							<label><input type="checkbox" name="<?php echo esc_attr( self::OPTION_BAR ); ?>" value="1" <?php checked( 1, get_option( self::OPTION_BAR, 0 ) ); ?>> Show reading progress bar</label><br>
							<label><input type="checkbox" name="<?php echo esc_attr( self::OPTION_COLLAPSE ); ?>" value="1" <?php checked( 1, get_option( self::OPTION_COLLAPSE, 0 ) ); ?>> Start TOC collapsed</label>
						</td>
					</tr>
				</table>

				<?php submit_button( 'Save Settings' ); ?>
			</form>

			<hr>
			<h2>Shortcode</h2>
			<p>Use <code>[bn_toc]</code> anywhere inside a post when shortcode-only mode is enabled.</p>

			<h2>Automatic behavior</h2>
			<ul>
				<li>Detects H2/H3/H4/H5/H6 headings according to your settings.</li>
				<li>Creates unique URL-safe anchor IDs.</li>
				<li>Preserves existing heading IDs when present.</li>
				<li>Skips headings with <code>data-bn-toc-ignore="1"</code>.</li>
				<li>Skips headings inside the generated TOC.</li>
				<li>Does not require an external JavaScript or CSS library.</li>
				<li>Does not modify post content permanently in the database.</li>
			</ul>

			<p><strong>Tip:</strong> To exclude a heading, use HTML like <code>&lt;h2 data-bn-toc-ignore="1"&gt;Heading&lt;/h2&gt;</code>.</p>
		</div>
		<?php
	}

	public static function enqueue_assets() {
		if ( ! is_singular( 'post' ) ) {
			return;
		}

		wp_register_style( 'bn-auto-toc', false, array(), self::VERSION );
		wp_enqueue_style( 'bn-auto-toc' );

		$css = '
		.bn-auto-toc{margin:0 0 28px;padding:0;border:1px solid #dbe4f0;border-radius:14px;background:#f8fbff;overflow:hidden;box-sizing:border-box;font-family:system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}
		.bn-auto-toc.bn-toc-sticky{position:sticky;top:20px;z-index:20}
		.bn-auto-toc-head{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:14px 16px;background:#fff;border-bottom:1px solid #e5edf6}
		.bn-auto-toc-title{font-size:16px;font-weight:700;color:#172033;line-height:1.3}
		.bn-auto-toc-toggle{border:1px solid #cbd8e8;background:#fff;color:#2563eb;border-radius:8px;padding:6px 10px;font-size:12px;font-weight:700;cursor:pointer}
		.bn-auto-toc-list{margin:0;padding:12px 16px 14px;list-style:none}
		.bn-auto-toc-list li{margin:0;padding:0}
		.bn-auto-toc-list li.bn-level-h3{padding-left:18px}
		.bn-auto-toc-list li.bn-level-h4{padding-left:34px}
		.bn-auto-toc-list li.bn-level-h5{padding-left:50px}
		.bn-auto-toc-list li.bn-level-h6{padding-left:66px}
		.bn-auto-toc-list a{display:block;padding:7px 9px;border-radius:7px;color:#334155;text-decoration:none;font-size:14px;line-height:1.45;transition:background .15s,color .15s}
		.bn-auto-toc-list a:hover{background:#eaf2ff;color:#1d4ed8}
		.bn-auto-toc-list a.bn-toc-active{background:#e7f0ff;color:#1d4ed8;font-weight:700}
		.bn-auto-toc.is-collapsed .bn-auto-toc-list{display:none}
		.bn-toc-progress{position:fixed;top:0;left:0;width:0;height:3px;background:#2563eb;z-index:99999;transition:width .08s linear}
		@media(max-width:700px){.bn-auto-toc.bn-toc-sticky{position:relative;top:auto}.bn-auto-toc-head{padding:12px}.bn-auto-toc-list{padding:10px 12px}.bn-auto-toc-list a{font-size:13px}}
		';
		wp_add_inline_style( 'bn-auto-toc', $css );

		wp_register_script( 'bn-auto-toc', false, array(), self::VERSION, true );
		wp_enqueue_script( 'bn-auto-toc' );

		$active = get_option( self::OPTION_ACTIVE, 1 );
		$bar    = get_option( self::OPTION_BAR, 0 );

		$js = '
		document.addEventListener("DOMContentLoaded",function(){
			const toc=document.querySelector(".bn-auto-toc");
			if(!toc)return;

			const toggle=toc.querySelector(".bn-auto-toc-toggle");
			if(toggle){
				toggle.addEventListener("click",function(){
					const collapsed=toc.classList.toggle("is-collapsed");
					toggle.setAttribute("aria-expanded",collapsed?"false":"true");
					toggle.textContent=collapsed?"Show":"Hide";
				});
			}

			toc.querySelectorAll("a[href^="#"]').forEach(function(a){
				a.addEventListener("click",function(e){
					const id=a.getAttribute("href").slice(1);
					const target=document.getElementById(id);
					if(!target)return;
					e.preventDefault();
					const y=target.getBoundingClientRect().top+window.pageYOffset-18;
					window.scrollTo({top:y,behavior:"smooth"});
					if(history.replaceState)history.replaceState(null,"","#"+id);
				});
			});

			' . ( $active ? '
			const links=[...toc.querySelectorAll(".bn-auto-toc-list a")];
			const targets=links.map(function(a){return document.getElementById(a.getAttribute("href").slice(1));}).filter(Boolean);
			if("IntersectionObserver" in window && targets.length){
				const observer=new IntersectionObserver(function(entries){
					entries.forEach(function(entry){
						if(entry.isIntersecting){
							links.forEach(function(l){l.classList.remove("bn-toc-active");});
							const link=toc.querySelector(\'a[href="#\'+entry.target.id+\'"]\');
							if(link)link.classList.add("bn-toc-active");
						}
					});
				},{rootMargin:"-20% 0px -65% 0px",threshold:0});
				targets.forEach(function(t){observer.observe(t);});
			}
			' : '' ) . '

			' . ( $bar ? '
			const bar=document.querySelector(".bn-toc-progress");
			if(bar){
				const update=function(){
					const doc=document.documentElement;
					const max=doc.scrollHeight-window.innerHeight;
					bar.style.width=(max>0?(window.scrollY/max)*100:0)+"%";
				};
				window.addEventListener("scroll",update,{passive:true});
				window.addEventListener("resize",update);
				update();
			}
			' : '' ) . '
		});
		';

		wp_add_inline_script( 'bn-auto-toc', $js );
	}

	public static function filter_content( $content ) {
		if ( ! is_singular( 'post' ) || ! in_the_loop() || ! is_main_query() ) {
			return $content;
		}

		if ( ! get_option( self::OPTION_AUTO, 1 ) ) {
			return $content;
		}

		if ( 'shortcode' === get_option( self::OPTION_POS, 'top' ) ) {
			return $content;
		}

		$parts = self::build_toc_and_content( $content );

		if ( empty( $parts['toc'] ) ) {
			return $content;
		}

		$position = get_option( self::OPTION_POS, 'top' );

		return 'bottom' === $position
			? $content . $parts['toc']
			: $parts['toc'] . $content;
	}

	public static function shortcode() {
		global $post;

		if ( ! $post instanceof WP_Post ) {
			return '';
		}

		$parts = self::build_toc_and_content( $post->post_content );

		return $parts['toc'];
	}

	private static function build_toc_and_content( $content ) {
		$levels = get_option( self::OPTION_LEVELS, 'h2,h3' );
		$levels = array_values( array_intersect( array( 'h2','h3','h4','h5','h6' ), array_map( 'trim', explode( ',', $levels ) ) ) );

		if ( empty( $levels ) ) {
			return array( 'toc' => '', 'content' => $content );
		}

		$pattern = '/<h([2-6])([^>]*)>(.*?)<\/h\1>/is';

		$items = array();
		$used  = array();
		$count = 0;

		$new_content = preg_replace_callback(
			$pattern,
			function( $match ) use ( &$items, &$used, &$count, $levels ) {
				$level = 'h' . $match[1];
				$attrs = $match[2];
				$inner = $match[3];

				if ( ! in_array( $level, $levels, true ) ) {
					return $match[0];
				}

				if ( preg_match( '/data-bn-toc-ignore\s*=\s*["\']?1["\']?/i', $attrs ) ) {
					return $match[0];
				}

				$text = trim( wp_strip_all_tags( $inner ) );

				if ( '' === $text ) {
					return $match[0];
				}

				$id = '';
				if ( preg_match( '/\bid\s*=\s*["\']([^"\']+)["\']/i', $attrs, $id_match ) ) {
					$id = sanitize_title( $id_match[1] );
				}

				if ( '' === $id ) {
					$id = sanitize_title( $text );
				}

				if ( '' === $id ) {
					$count++;
					$id = 'section-' . $count;
				}

				$base = $id;
				$i    = 2;
				while ( isset( $used[ $id ] ) ) {
					$id = $base . '-' . $i;
					$i++;
				}
				$used[ $id ] = true;

				if ( preg_match( '/\bid\s*=/i', $attrs ) ) {
					$attrs = preg_replace(
						'/\bid\s*=\s*(["\'])(.*?)\1/i',
						'id="' . esc_attr( $id ) . '"',
						$attrs,
						1
					);
				} else {
					$attrs .= ' id="' . esc_attr( $id ) . '"';
				}

				$items[] = array(
					'id'    => $id,
					'text'  => $text,
					'level' => $level,
				);

				return '<h' . $match[1] . $attrs . '>' . $inner . '</h' . $match[1] . '>';
			},
			$content
		);

		if ( empty( $items ) ) {
			return array( 'toc' => '', 'content' => $content );
		}

		$title    = get_option( self::OPTION_TITLE, 'Table of Contents' );
		$sticky   = get_option( self::OPTION_STICKY, 0 );
		$collapse = get_option( self::OPTION_COLLAPSE, 0 );
		$bar      = get_option( self::OPTION_BAR, 0 );

		$class = 'bn-auto-toc' . ( $sticky ? ' bn-toc-sticky' : '' ) . ( $collapse ? ' is-collapsed' : '' );

		$html = '<nav class="' . esc_attr( $class ) . '" aria-label="' . esc_attr( $title ) . '">';
		$html .= '<div class="bn-auto-toc-head">';
		$html .= '<div class="bn-auto-toc-title">' . esc_html( $title ) . '</div>';
		$html .= '<button type="button" class="bn-auto-toc-toggle" aria-expanded="' . ( $collapse ? 'false' : 'true' ) . '">' . ( $collapse ? 'Show' : 'Hide' ) . '</button>';
		$html .= '</div>';
		$html .= '<ol class="bn-auto-toc-list">';

		foreach ( $items as $item ) {
			$html .= '<li class="bn-level-' . esc_attr( $item['level'] ) . '">';
			$html .= '<a href="#' . esc_attr( $item['id'] ) . '">' . esc_html( $item['text'] ) . '</a>';
			$html .= '</li>';
		}

		$html .= '</ol></nav>';

		if ( $bar ) {
			$html .= '<div class="bn-toc-progress" aria-hidden="true"></div>';
		}

		return array(
			'toc'     => $html,
			'content' => $new_content,
		);
	}
}

ByteNexo_Auto_TOC::init();
register_activation_hook( __FILE__, array( 'ByteNexo_Auto_TOC', 'activate' ) );
