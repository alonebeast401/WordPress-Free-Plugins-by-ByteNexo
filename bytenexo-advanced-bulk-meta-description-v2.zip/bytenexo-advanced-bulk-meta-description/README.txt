# ByteNexo Advanced Bulk Meta Description 2.0

This version adds a dedicated **Meta Description Bulk Edit** option directly to the WordPress Posts > Bulk Actions dropdown.

## Workflow

1. Go to Posts > All Posts.
2. Select at least 10 posts.
3. Open Bulk Actions.
4. Select **Meta Description Bulk Edit**.
5. Click Apply.
6. A bulk editor opens with exactly 10 post cards.
7. Each card shows the post title and its own Meta Description box.
8. Enter a different description in every box.
9. Press **Apply All 10 Descriptions** once.
10. All 10 descriptions are saved to their corresponding posts in one request.

The post title and content are never modified by this plugin.

Existing descriptions are loaded into the boxes so they can be edited. Leaving a box empty removes the custom description for that post.

Maximum: 160 characters per description.

The plugin passes the saved value to Rank Math and Yoast SEO when those plugins are active. Without a supported SEO plugin it outputs the meta description tag itself.

If more than 10 posts are selected, the first 10 selected posts are opened in the editor. This keeps the editor at a clean 10-box layout.
