<?php
/**
 * Plugin Name: ByteNexo Advanced Bulk Meta Description
 * Description: Adds an advanced 10-post Meta Description editor to WordPress Bulk Actions. Enter a different description for each selected post and apply them all at once.
 * Version: 2.0.0
 * Author: ByteNexo
 * License: GPL-2.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class ByteNexo_Advanced_Bulk_Meta_Description {

	const META_KEY     = '_bytenexo_meta_description';
	const NONCE_ACTION = 'bytenexo_qmd_advanced';

	public function __construct() {
		add_filter( 'bulk_actions-edit-post', array( $this, 'add_bulk_action' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'admin_assets' ) );

		add_action( 'wp_ajax_bytenexo_bulk_editor_posts', array( $this, 'ajax_get_posts' ) );
		add_action( 'wp_ajax_bytenexo_save_bulk_descriptions', array( $this, 'ajax_save_descriptions' ) );

		// Rank Math.
		add_filter( 'rank_math/frontend/description', array( $this, 'rank_math_description' ), 99 );

		// Yoast SEO.
		add_filter( 'wpseo_metadesc', array( $this, 'yoast_description' ), 99 );

		// Fallback when no supported SEO plugin controls the tag.
		add_action( 'wp_head', array( $this, 'output_meta_description' ), 1 );
	}

	public function add_bulk_action( $actions ) {
		$actions['bytenexo_bulk_meta_description'] = 'Meta Description Bulk Edit';
		return $actions;
	}

	public function admin_assets( $hook ) {
		if ( 'edit.php' !== $hook ) {
			return;
		}

		$screen = get_current_screen();

		if ( ! $screen || 'post' !== $screen->post_type ) {
			return;
		}

		wp_enqueue_script( 'jquery' );

		wp_add_inline_script(
			'jquery',
			'window.ByteNexoQMDAdvanced = ' . wp_json_encode(
				array(
					'nonce' => wp_create_nonce( self::NONCE_ACTION ),
				)
			) . ';',
			'before'
		);

		$js = <<<'JS'
(function($){
	'use strict';

	var actionName = 'bytenexo_bulk_meta_description';
	var maxBoxes = 10;
	var modalOpen = false;

	/*
	 * Intercept both WordPress Bulk Actions buttons.
	 * The normal WordPress bulk request is prevented only for our custom action.
	 */
	$(document).on('click', '#doaction, #doaction2', function(e){
		var button = $(this);
		var form = button.closest('form');

		var select = button.attr('id') === 'doaction2'
			? form.find('select[name="action2"]')
			: form.find('select[name="action"]');

		if (!select.length || select.val() !== actionName) {
			return;
		}

		e.preventDefault();

		var ids = [];
		form.find('input[name="post[]"]:checked').each(function(){
			var id = parseInt($(this).val(), 10);
			if (id) {
				ids.push(id);
			}
		});

		/*
		 * The advanced editor is designed for 10 posts at a time.
		 * If more than 10 are selected, the first 10 are opened.
		 */
		if (ids.length < 10) {
			alert('Please select at least 10 posts to use Meta Description Bulk Edit.');
			return;
		}

		ids = ids.slice(0, maxBoxes);
		openEditor(ids);
	});

	function openEditor(ids) {
		if (modalOpen) {
			return;
		}

		modalOpen = true;
		showLoading();

		$.post(ajaxurl, {
			action: 'bytenexo_bulk_editor_posts',
			nonce: ByteNexoQMDAdvanced.nonce,
			post_ids: ids
		}).done(function(response){
			if (response && response.success) {
				renderEditor(response.data.posts);
			} else {
				closeEditor();
				alert('Could not load the selected posts.');
			}
		}).fail(function(){
			closeEditor();
			alert('Could not load the selected posts. Please try again.');
		});
	}

	function showLoading() {
		var html = ''
			+ '<div id="bytenexo-qmd-advanced-overlay">'
			+   '<div id="bytenexo-qmd-advanced-modal" class="bytenexo-loading-modal">'
			+     '<div class="bytenexo-spinner"></div>'
			+     '<div>Loading selected posts...</div>'
			+   '</div>'
			+ '</div>';

		$('body').append(html);
	}

	function renderEditor(posts) {
		var html = ''
			+ '<div id="bytenexo-qmd-advanced-overlay">'
			+   '<div id="bytenexo-qmd-advanced-modal">'
			+     '<div class="bytenexo-qmd-header">'
			+       '<div>'
			+         '<h2>Meta Description Bulk Edit</h2>'
			+         '<p>Write a different meta description for each post. All 10 will be saved with one click.</p>'
			+       '</div>'
			+       '<button type="button" id="bytenexo-qmd-advanced-close" aria-label="Close">×</button>'
			+     '</div>'
			+     '<div class="bytenexo-qmd-grid">';

		for (var i = 0; i < posts.length; i++) {
			var post = posts[i];
			var value = escapeHtml(post.description || '');

			html += ''
				+ '<div class="bytenexo-qmd-card">'
				+   '<div class="bytenexo-qmd-post-number">POST ' + (i + 1) + '</div>'
				+   '<div class="bytenexo-qmd-title" title="' + escapeAttr(post.title) + '">' + escapeHtml(post.title) + '</div>'
				+   '<div class="bytenexo-qmd-id">ID: ' + parseInt(post.id, 10) + '</div>'
				+   '<textarea class="bytenexo-qmd-description" data-post-id="' + parseInt(post.id, 10) + '" maxlength="160" rows="4" placeholder="Enter meta description...">' + value + '</textarea>'
				+   '<div class="bytenexo-qmd-card-footer"><span class="bytenexo-qmd-counter">0 / 160</span></div>'
				+ '</div>';
		}

		html += ''
			+     '</div>'
			+     '<div class="bytenexo-qmd-footer">'
			+       '<div class="bytenexo-qmd-summary"><strong>10 posts</strong> selected</div>'
			+       '<div class="bytenexo-qmd-footer-actions">'
			+         '<button type="button" class="button" id="bytenexo-qmd-advanced-cancel">Cancel</button>'
			+         '<button type="button" class="button button-primary bytenexo-qmd-apply" id="bytenexo-qmd-advanced-apply">Apply All 10 Descriptions</button>'
			+       '</div>'
			+     '</div>'
			+   '</div>'
			+ '</div>';

		$('#bytenexo-qmd-advanced-overlay').remove();
		$('body').append(html);

		$('.bytenexo-qmd-description').each(function(){
			updateCounter($(this));
		});

		$(document).on('input.bytenexoQMD', '.bytenexo-qmd-description', function(){
			var field = $(this);

			if (field.val().length > 160) {
				field.val(field.val().substring(0, 160));
			}

			updateCounter(field);
		});

		$('#bytenexo-qmd-advanced-close, #bytenexo-qmd-advanced-cancel').on('click', closeEditor);

		$('#bytenexo-qmd-advanced-apply').on('click', function(){
			saveAll(posts);
		});

		// Escape closes the editor.
		$(document).on('keydown.bytenexoQMD', function(e){
			if (e.key === 'Escape') {
				closeEditor();
			}
		});
	}

	function updateCounter(field) {
		var count = field.val().length;
		field.closest('.bytenexo-qmd-card').find('.bytenexo-qmd-counter').text(count + ' / 160');
	}

	function saveAll(posts) {
		var descriptions = [];
		var valid = true;

		$('.bytenexo-qmd-description').each(function(){
			var field = $(this);
			var postId = parseInt(field.attr('data-post-id'), 10);
			var description = field.val().trim();

			if (!postId) {
				valid = false;
				return false;
			}

			descriptions.push({
				id: postId,
				description: description
			});
		});

		if (!valid || descriptions.length !== posts.length) {
			alert('Please check the selected posts and try again.');
			return;
		}

		var button = $('#bytenexo-qmd-advanced-apply');
		button.prop('disabled', true).text('Applying...');

		$.post(ajaxurl, {
			action: 'bytenexo_save_bulk_descriptions',
			nonce: ByteNexoQMDAdvanced.nonce,
			descriptions: descriptions
		}).done(function(response){
			if (response && response.success) {
				button.text('Saved Successfully');
				setTimeout(function(){
					closeEditor();
					window.location.reload();
				}, 650);
			} else {
				button.prop('disabled', false).text('Apply All 10 Descriptions');
				alert('Some descriptions could not be saved.');
			}
		}).fail(function(){
			button.prop('disabled', false).text('Apply All 10 Descriptions');
			alert('Could not save the descriptions. Please try again.');
		});
	}

	function closeEditor() {
		$('#bytenexo-qmd-advanced-overlay').remove();
		$(document).off('.bytenexoQMD');
		modalOpen = false;
	}

	function escapeHtml(text) {
		return String(text)
			.replace(/&/g, '&amp;')
			.replace(/</g, '&lt;')
			.replace(/>/g, '&gt;')
			.replace(/"/g, '&quot;')
			.replace(/'/g, '&#039;');
	}

	function escapeAttr(text) {
		return escapeHtml(text);
	}

})(jQuery);
JS;

		wp_add_inline_script( 'jquery', $js );

		$css = <<<'CSS'
#bytenexo-qmd-advanced-overlay {
	position: fixed;
	z-index: 100000;
	inset: 0;
	background: rgba(0,0,0,.58);
	display: flex;
	align-items: center;
	justify-content: center;
	padding: 18px;
	box-sizing: border-box;
}

#bytenexo-qmd-advanced-modal {
	width: min(1100px, 100%);
	max-height: 94vh;
	overflow: auto;
	background: #fff;
	border-radius: 12px;
	box-shadow: 0 18px 60px rgba(0,0,0,.35);
	box-sizing: border-box;
}

.bytenexo-qmd-header {
	position: sticky;
	top: 0;
	z-index: 2;
	display: flex;
	align-items: flex-start;
	justify-content: space-between;
	gap: 18px;
	padding: 20px 22px 16px;
	background: #fff;
	border-bottom: 1px solid #e2e4e7;
}

.bytenexo-qmd-header h2 {
	margin: 0 0 5px;
	font-size: 22px;
	line-height: 1.3;
}

.bytenexo-qmd-header p {
	margin: 0;
	color: #646970;
	font-size: 13px;
}

#bytenexo-qmd-advanced-close {
	border: 0;
	background: transparent;
	cursor: pointer;
	font-size: 30px;
	line-height: 1;
	padding: 0 3px;
	color: #50575e;
}

.bytenexo-qmd-grid {
	display: grid;
	grid-template-columns: repeat(2, minmax(0, 1fr));
	gap: 14px;
	padding: 18px 22px;
}

.bytenexo-qmd-card {
	border: 1px solid #dcdcde;
	border-radius: 9px;
	padding: 14px;
	background: #fff;
	box-sizing: border-box;
}

.bytenexo-qmd-post-number {
	font-size: 11px;
	font-weight: 700;
	letter-spacing: .7px;
	color: #2271b1;
	margin-bottom: 5px;
}

.bytenexo-qmd-title {
	font-size: 15px;
	font-weight: 600;
	line-height: 1.4;
	margin-bottom: 3px;
	white-space: nowrap;
	overflow: hidden;
	text-overflow: ellipsis;
}

.bytenexo-qmd-id {
	font-size: 11px;
	color: #8c8f94;
	margin-bottom: 10px;
}

.bytenexo-qmd-description {
	display: block;
	width: 100%;
	min-height: 86px;
	resize: vertical;
	box-sizing: border-box;
	border: 1px solid #8c8f94;
	border-radius: 6px;
	padding: 9px 10px;
	font-size: 13px;
	line-height: 1.45;
}

.bytenexo-qmd-description:focus {
	border-color: #2271b1;
	box-shadow: 0 0 0 1px #2271b1;
	outline: 0;
}

.bytenexo-qmd-card-footer {
	display: flex;
	justify-content: flex-end;
	margin-top: 5px;
	color: #646970;
	font-size: 11px;
}

.bytenexo-qmd-footer {
	position: sticky;
	bottom: 0;
	z-index: 2;
	display: flex;
	align-items: center;
	justify-content: space-between;
	gap: 16px;
	padding: 15px 22px;
	background: #fff;
	border-top: 1px solid #e2e4e7;
}

.bytenexo-qmd-summary {
	color: #50575e;
	font-size: 13px;
}

.bytenexo-qmd-footer-actions {
	display: flex;
	align-items: center;
	gap: 8px;
}

.bytenexo-qmd-apply {
	min-width: 190px;
}

.bytenexo-loading-modal {
	display: flex;
	align-items: center;
	gap: 12px;
	justify-content: center;
	padding: 35px;
	font-size: 14px;
}

.bytenexo-spinner {
	width: 20px;
	height: 20px;
	border: 2px solid #dcdcde;
	border-top-color: #2271b1;
	border-radius: 50%;
	animation: bytenexoSpin .7s linear infinite;
}

@keyframes bytenexoSpin {
	to { transform: rotate(360deg); }
}

@media (max-width: 782px) {
	#bytenexo-qmd-advanced-overlay {
		padding: 8px;
		align-items: flex-start;
	}

	#bytenexo-qmd-advanced-modal {
		max-height: 98vh;
		margin-top: 4px;
	}

	.bytenexo-qmd-header {
		padding: 16px;
	}

	.bytenexo-qmd-grid {
		grid-template-columns: 1fr;
		padding: 14px 16px;
		gap: 10px;
	}

	.bytenexo-qmd-footer {
		padding: 12px 16px;
		flex-direction: column;
		align-items: stretch;
	}

	.bytenexo-qmd-footer-actions {
		width: 100%;
	}

	.bytenexo-qmd-footer-actions button {
		flex: 1;
	}
}
CSS;

		wp_add_inline_style( 'dashicons', $css );
	}

	/**
	 * Return titles and current descriptions for selected posts.
	 */
	public function ajax_get_posts() {
		check_ajax_referer( self::NONCE_ACTION, 'nonce' );

		if ( ! current_user_can( 'edit_posts' ) ) {
			wp_send_json_error( array( 'message' => 'Permission denied.' ), 403 );
		}

		$post_ids = isset( $_POST['post_ids'] ) ? (array) $_POST['post_ids'] : array();
		$post_ids = array_values( array_filter( array_map( 'absint', $post_ids ) ) );

		if ( count( $post_ids ) < 10 ) {
			wp_send_json_error( array( 'message' => 'At least 10 posts are required.' ) );
		}

		$post_ids = array_slice( $post_ids, 0, 10 );
		$posts    = array();

		foreach ( $post_ids as $post_id ) {
			if ( 'post' !== get_post_type( $post_id ) || ! current_user_can( 'edit_post', $post_id ) ) {
				continue;
			}

			$title = get_the_title( $post_id );

			if ( '' === $title ) {
				$title = '(No title)';
			}

			$posts[] = array(
				'id'          => $post_id,
				'title'       => $title,
				'description' => $this->get_description( $post_id ),
			);
		}

		if ( count( $posts ) < 10 ) {
			wp_send_json_error( array( 'message' => 'Please select 10 editable posts.' ) );
		}

		wp_send_json_success( array( 'posts' => $posts ) );
	}

	/**
	 * Save 10 independent descriptions in one request.
	 */
	public function ajax_save_descriptions() {
		check_ajax_referer( self::NONCE_ACTION, 'nonce' );

		if ( ! current_user_can( 'edit_posts' ) ) {
			wp_send_json_error( array( 'message' => 'Permission denied.' ), 403 );
		}

		$items = isset( $_POST['descriptions'] ) ? (array) $_POST['descriptions'] : array();

		if ( count( $items ) < 10 ) {
			wp_send_json_error( array( 'message' => 'Exactly 10 descriptions are required.' ) );
		}

		$saved = 0;

		foreach ( array_slice( $items, 0, 10 ) as $item ) {
			$post_id = isset( $item['id'] ) ? absint( $item['id'] ) : 0;

			$description = isset( $item['description'] )
				? sanitize_textarea_field( wp_unslash( $item['description'] ) )
				: '';

			$description = function_exists( 'mb_substr' )
				? mb_substr( $description, 0, 160 )
				: substr( $description, 0, 160 );

			if ( ! $post_id || 'post' !== get_post_type( $post_id ) || ! current_user_can( 'edit_post', $post_id ) ) {
				continue;
			}

			if ( '' === trim( $description ) ) {
				delete_post_meta( $post_id, self::META_KEY );
			} else {
				update_post_meta( $post_id, self::META_KEY, $description );
			}

			$saved++;
		}

		if ( $saved !== 10 ) {
			wp_send_json_error(
				array(
					'message' => 'Only ' . $saved . ' of 10 descriptions could be saved.',
				)
			);
		}

		wp_send_json_success( array( 'saved' => $saved ) );
	}

	private function get_description( $post_id ) {
		$value = get_post_meta( $post_id, self::META_KEY, true );
		return is_string( $value ) ? trim( $value ) : '';
	}

	public function rank_math_description( $description ) {
		if ( ! is_singular( 'post' ) ) {
			return $description;
		}

		$value = $this->get_description( get_queried_object_id() );

		return '' !== $value ? $value : $description;
	}

	public function yoast_description( $description ) {
		if ( ! is_singular( 'post' ) ) {
			return $description;
		}

		$value = $this->get_description( get_queried_object_id() );

		return '' !== $value ? $value : $description;
	}

	public function output_meta_description() {
		if ( ! is_singular( 'post' ) ) {
			return;
		}

		$value = $this->get_description( get_queried_object_id() );

		if ( '' === $value ) {
			return;
		}

		if (
			defined( 'WPSEO_VERSION' ) ||
			defined( 'RANK_MATH_VERSION' ) ||
			defined( 'AIOSEO_VERSION' ) ||
			defined( 'SEOPRESS_VERSION' ) ||
			defined( 'THE_SEO_FRAME_VERSION' )
		) {
			return;
		}

		echo '<meta name="description" content="' . esc_attr( $value ) . '">' . "\n";
	}
}

new ByteNexo_Advanced_Bulk_Meta_Description();
