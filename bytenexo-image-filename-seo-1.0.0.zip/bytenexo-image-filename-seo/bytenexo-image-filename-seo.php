<?php
/**
 * Plugin Name: ByteNexo Image Filename SEO
 * Plugin URI: https://bytenexo.in/
 * Description: Professionally cleans new image filenames while preserving numbers, extensions, and readable words.
 * Version: 1.0.0
 * Author: ByteNexo
 * Author URI: https://bytenexo.in/
 * License: GPL-2.0-or-later
 * Requires at least: 5.8
 * Requires PHP: 7.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class ByteNexo_Image_Filename_SEO {

	const OPTION_ENABLED = 'bn_ifs_enabled';
	const OPTION_LOG     = 'bn_ifs_log';

	public static function init() {
		add_filter( 'sanitize_file_name', array( __CLASS__, 'sanitize_filename' ), 20, 1 );
		add_action( 'admin_menu', array( __CLASS__, 'admin_menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), array( __CLASS__, 'settings_link' ) );
	}

	public static function activate() {
		if ( false === get_option( self::OPTION_ENABLED ) ) {
			add_option( self::OPTION_ENABLED, 1 );
		}
		if ( false === get_option( self::OPTION_LOG ) ) {
			add_option( self::OPTION_LOG, 1 );
		}
	}

	public static function register_settings() {
		register_setting(
			'bn_ifs_settings',
			self::OPTION_ENABLED,
			array(
				'type'              => 'boolean',
				'sanitize_callback' => function( $value ) { return empty( $value ) ? 0 : 1; },
				'default'           => 1,
			)
		);

		register_setting(
			'bn_ifs_settings',
			self::OPTION_LOG,
			array(
				'type'              => 'boolean',
				'sanitize_callback' => function( $value ) { return empty( $value ) ? 0 : 1; },
				'default'           => 1,
			)
		);
	}

	public static function admin_menu() {
		add_options_page(
			'ByteNexo Image Filename SEO',
			'ByteNexo Image SEO',
			'manage_options',
			'bn-image-filename-seo',
			array( __CLASS__, 'settings_page' )
		);
	}

	public static function settings_link( $links ) {
		$url = admin_url( 'options-general.php?page=bn-image-filename-seo' );
		array_unshift( $links, '<a href="' . esc_url( $url ) . '">Settings</a>' );
		return $links;
	}

	public static function settings_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		?>
		<div class="wrap">
			<h1>ByteNexo Image Filename SEO</h1>

			<p>
				Cleans filenames automatically when new files are uploaded to the WordPress Media Library.
				Numbers are preserved.
			</p>

			<form method="post" action="options.php">
				<?php settings_fields( 'bn_ifs_settings' ); ?>

				<table class="form-table" role="presentation">
					<tr>
						<th scope="row">Automatic filename cleanup</th>
						<td>
							<label>
								<input type="checkbox"
									name="<?php echo esc_attr( self::OPTION_ENABLED ); ?>"
									value="1"
									<?php checked( 1, get_option( self::OPTION_ENABLED, 1 ) ); ?>>
								Enable automatic cleanup for new uploads
							</label>
						</td>
					</tr>

					<tr>
						<th scope="row">Keep filename log</th>
						<td>
							<label>
								<input type="checkbox"
									name="<?php echo esc_attr( self::OPTION_LOG ); ?>"
									value="1"
									<?php checked( 1, get_option( self::OPTION_LOG, 1 ) ); ?>>
								Keep a simple log in the Media Library attachment metadata
							</label>
						</td>
					</tr>
				</table>

				<?php submit_button( 'Save Settings' ); ?>
			</form>

			<hr>

			<h2>Filename rules</h2>
			<ul>
				<li><code>My Image 2026!.jpg</code> → <code>my-image-2026.jpg</code></li>
				<li><code>GTA 6 Gameplay 2026.png</code> → <code>gta-6-gameplay-2026.png</code></li>
				<li><code>273837.jpg</code> → <code>273837.jpg</code></li>
				<li>Numbers are never intentionally removed.</li>
				<li>Spaces become hyphens.</li>
				<li>Letters are converted to lowercase.</li>
				<li>Repeated hyphens and unnecessary leading/trailing hyphens are removed.</li>
				<li>The file extension is preserved.</li>
			</ul>

			<p><strong>Important:</strong> This plugin only changes filenames during upload. It does not rename existing Media Library files.</p>
		</div>
		<?php
	}

	public static function sanitize_filename( $filename ) {
		if ( ! get_option( self::OPTION_ENABLED, 1 ) ) {
			return $filename;
		}

		$original = $filename;
		$filename = wp_strip_all_tags( (string) $filename );
		$filename = remove_accents( $filename );

		$extension = '';
		$dot_pos   = strrpos( $filename, '.' );

		if ( false !== $dot_pos && $dot_pos > 0 ) {
			$extension = substr( $filename, $dot_pos );
			$filename  = substr( $filename, 0, $dot_pos );
		}

		$filename = strtolower( $filename );

		// Replace every non-letter/non-number run with one hyphen.
		$filename = preg_replace( '/[^a-z0-9]+/i', '-', $filename );
		$filename = preg_replace( '/-+/', '-', $filename );
		$filename = trim( $filename, '-' );

		// Keep a usable fallback for unusual filenames.
		if ( '' === $filename ) {
			$filename = 'image';
		}

		$extension = strtolower( preg_replace( '/[^a-z0-9.]/i', '', $extension ) );

		$clean = $filename . $extension;

		/**
		 * Do not log here because this filter can run before an attachment ID exists.
		 * The cleaned filename is returned to WordPress for the upload process.
		 */
		return $clean;
	}
}

ByteNexo_Image_Filename_SEO::init();
register_activation_hook( __FILE__, array( 'ByteNexo_Image_Filename_SEO', 'activate' ) );
