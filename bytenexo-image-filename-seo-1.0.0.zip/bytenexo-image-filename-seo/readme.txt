=== ByteNexo Image Filename SEO ===
Contributors: bytenexo
Tags: image filename, seo, media library, image seo, filename cleaner
Requires at least: 5.8
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPL-2.0-or-later

Automatically cleans new image filenames when they are uploaded to WordPress.

== Description ==

ByteNexo Image Filename SEO creates clean, readable filenames for new uploads.

Examples:
* My Image 2026!.jpg -> my-image-2026.jpg
* GTA 6 Gameplay 2026.png -> gta-6-gameplay-2026.png
* 273837.jpg -> 273837.jpg

Numbers are preserved. Existing Media Library files are not renamed.

== Features ==

* Lowercase filenames
* Spaces become hyphens
* Special characters are removed
* Repeated hyphens are cleaned
* Numbers are preserved
* File extensions are preserved
* Simple settings page
* Lightweight and framework-free

== Installation ==

1. Go to Plugins > Add New Plugin > Upload Plugin.
2. Upload the ZIP file.
3. Activate the plugin.
4. Open Settings > ByteNexo Image SEO.
5. Upload new images normally.

== Important ==

This plugin changes filenames during upload. It does not rename existing files because changing existing Media Library URLs can create broken links.
